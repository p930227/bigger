# -*- coding: utf-8 -*-
"""
Created on Wed May 22 15:37:40 2019

@author: PARK
"""

import pandas as pd
import matplotlib.pyplot as plt

#####---GDP Function---#####

# GDP_Data 전처리 함수
def GDP_Pre() :
    Data_GDP = pd.read_csv('gdp.csv')
    New_Data_GDP = Data_GDP.set_index('Y_Q')    
    return New_Data_GDP 

# 전체 GDP 출력 함수
def GDP_All(GC) :    
    New_Data_GDP=GDP_Pre()    
    if GC == 'Y' :
        print(New_Data_GDP)
        plt.plot(New_Data_GDP)
    elif GC == 'N' :
        return 1
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        GC=input("2006_1분기부터 2019_1분기까지의 GDP를 확인하시겠습니까 (Y/N) ?").upper()
        GDP_All(GC)
        
        
# 년/분기별 개별 GDP 출력 함수
def GDP_Y_Q(GC):
    New_Data_GDP=GDP_Pre()  
    if GC == 'Y' :
        Y_Q = input("연도_분기를 입력하시오(ex : '2012_3')")
        print(New_Data_GDP.loc[Y_Q])
        return 1
    elif GC == 'N' :
        return 1
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        GDP_Confirm=input("특정 년도/분기의 GDP를 확인하시겠습니까 (Y/N) ?").upper()
        GDP_Y_Q(GDP_Confirm)