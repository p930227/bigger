# -*- coding: utf-8 -*-
"""
Created on Fri May 31 20:47:55 2019

@author: PARK
"""

import GDP_Container_Ft as GCF
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from datetime import datetime
from fbprophet import Prophet

# Time_Series 전처리 함수
def Time_Series_Pre() :
    
    Data, temp = GCF.GDP_Container_Pre()
    dates = list(Data.index)
    dates = [item.replace('_','-') for item in dates ]
    dates_index = pd.DatetimeIndex(dates)
    GDP=list(Data['GDP'])
    Col = ['GDP']
    Time_Series = pd.DataFrame(data=GDP, index = dates_index, columns=Col)
    Time_Series['Container'] = list(Data['Container'])

    return Time_Series
    
# 전체기간에 대한 Time_Series 함수    
def All_Time(TS_Confrim) :

    if TS_Confrim == 'Y':
 
        Time_Series = Time_Series_Pre()

        # 시계열 예측을 위한 DataFrame으로 변환
        Predict_GDP = pd.DataFrame({'ds':Time_Series.index, 'y':Time_Series['GDP']})

        # Container Columns을 연도별로 GDP Columns에 적합 (Fitted)
        m=Prophet()
        m.fit(Predict_GDP)
        future = m.make_future_dataframe(periods=31)
        forecast = m.predict(future)
        forecast = forecast[forecast['ds'] == '2019-02-01']
        print("2019 2분기 예측 값( for 95% 신뢰도 ) = ", forecast['yhat'])
        print("2019 2분기 예측 상한 값( for 95% 신뢰도 ) = ", forecast['yhat_upper'])
        print("2019 2분기 예측 하한 값( for 95% 신뢰도 ) = ", forecast['yhat_lower'])

        
        return Predict_GDP
        
    elif TS_Confrim == 'N' :
        return 1 
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        TS_Confrim = input("Time_Series 모델로 적합한 적합 모델의 Time_Series 그래프와 2019년도 2분기 예측값을 확인하시겠습니까 (Y/N) ?").upper()
        All_Time(TS_Confrim)


# Outlier value인 'Subprime_Mortage'에의한 '경제대공황' Data(2008년) 제거 후 재적합한 Time_Series 함수
def Del_Time(TS_Confrim) :

    if TS_Confrim == 'Y':
 
        Time_Series = Time_Series_Pre()
        Time_Series.drop(Time_Series.index[8], inplace = True)      # 2008년 1분기
        Time_Series.drop(Time_Series.index[8], inplace = True)      # 2008년 2분기
        Time_Series.drop(Time_Series.index[8], inplace = True)     # 2008년 3분기
        Time_Series.drop(Time_Series.index[8], inplace = True)     # 2008년 4분기

        # 시계열 예측을 위한 DataFrame으로 변환
        Predict_GDP = pd.DataFrame({'ds':Time_Series.index, 'y':Time_Series['GDP']})

        # Container Columns을 연도별로 GDP Columns에 적합 (Fitted)
        m=Prophet()
        m.fit(Predict_GDP)
        future = m.make_future_dataframe(periods=31)
        forecast = m.predict(future)
        forecast = forecast[forecast['ds'] == '2019-02-01']
        print("2019 2분기 예측 값( for 95% 신뢰도 ) = ", forecast['yhat'])
        print("2019 2분기 예측 상한 값( for 95% 신뢰도 ) = ", forecast['yhat_upper'])
        print("2019 2분기 예측 하한 값( for 95% 신뢰도 ) = ", forecast['yhat_lower'])
        
        return Predict_GDP
                
    elif TS_Confrim == 'N' :
        return 1
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        TS_Confrim = input("2008년(경제대공황)을 제외하고 적합한 적합 모델의 Time_Series 그래프와 2019년도 2분기 예측값을 확인하시겠습니까 (Y/N) ?").upper()
        Del_Time(TS_Confrim)

