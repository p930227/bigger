# -*- coding: utf-8 -*-
"""
Created on Wed May 22 18:49:56 2019

@author: PARK
"""

import pandas as pd
import matplotlib.pyplot as plt

import GDP_Ft as GF
import Container_Ft as CF

#####---GDP & Container---#####

# GDP & Container 각각 DataFrame을 하나로 병합 후 Data로 명명
def GDP_Container_Pre() :
    GDP = GF.GDP_Pre()
    GDP_mult = 1000000*GF.GDP_Pre()
    Container = CF.Container_Pre()
    Data = pd.merge(GDP, Container, on='Y_Q')
    Data_mult = pd.merge(GDP_mult, Container, on='Y_Q')
    return Data, Data_mult

# Data Plot
def Data_Plot(PC):
    
    if PC == 'Y' :
        Data, Data_mult = GDP_Container_Pre()
        plt.plot(Data_mult)
        plt.ylabel('년_분기')
        plt.ylabel('GDP & Container')
        xbar1 = ['2006_1','2007_1','2008_1','2009_1','2010_1','2011_1','2012_1',
                 '2013_1','2014_1','2015_1','2016_1','2017_1','2018_1','2019_1']
        ybar = [6000000]
        plt.bar(xbar1,ybar,width=0.2, color='blue')
        xbar2 = ['2006_2','2007_2','2008_2','2009_2','2010_2','2011_2','2012_2',
                 '2013_2','2014_2','2015_2','2016_2','2017_2','2018_2','2019_2']
        plt.bar(xbar2,ybar,width=0.1, color='red')
    elif PC == 'N' :
        return 1
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        Plot_Confrim = input("1분기보다 2분기의 경제성장률이 좋았던 적이 있는지 그래프로 확인하시겠습니까 (Y/N) ?").upper()
        Data_Plot(Plot_Confrim)
    
    
   
    

    

