# -*- coding: utf-8 -*-
"""
Created on Wed May 22 17:30:04 2019

@author: PARK
"""

import pandas as pd
import matplotlib.pyplot as plt

#####---Container Function---#####


# Container_Data 전처리 함수
def Container_Pre() :
    
    # 필요한 칼럼만 불러오기
    Data_Container = pd.read_csv('container.csv')
    Data_Container=Data_Container['TEU소계']

    # 불필요한 Record 삭제
    Data_Container=Data_Container.drop(0)    
    i=1
    while i <= 491  :
        Data_Container=Data_Container.drop(i)
        i = i + 37
    # index 재정렬
    Data_Container = Data_Container.reset_index(drop=True)


    # 필요한 Record만 추출
    Data_Container=Data_Container.iloc[0:476:3]
    #index 재정렬
    Data_Container = Data_Container.reset_index(drop=True)

    # 쉼표(,) 떼기 -> list로 반환됨
    Data_Container = [float((item.replace(',',''))) for item in Data_Container ]

    # 월별 Data를 분기별로 재정렬
    i=0
    while i <= 156 :
        Data_Container[i] = Data_Container[i] + Data_Container[i+1] + Data_Container[i+2]    
        i =  i + 3   
        
    # list를 DataFrame으로 만들기
    Data_Container=pd.DataFrame(Data_Container)

    # 불필요한데이터 지우기    
    i=0
    while i <= 156 :
        Data_Container.drop(i+1, inplace = True)
        Data_Container.drop(i+2, inplace = True)
        i =  i + 3
        
    # index 재정렬
    Data_Container = Data_Container.reset_index(drop=True)            
    
    # GDP Data에서 index로 쓸 columns 추출
    Data_GDP = pd.read_csv('gdp.csv')
    Data_Container['Y_Q'] = Data_GDP['Y_Q']

    # 추출한 columns을 index로 지정
    Data_Container = Data_Container.set_index('Y_Q') 
    New_Data_Container=Data_Container.rename(columns={0:'Container'})

    return New_Data_Container


# 전체 Container 출력 함수
def Container_All(CC) :    
     New_Data_Container=Container_Pre()   
     if CC == 'Y' :
        print(New_Data_Container)
        plt.plot(New_Data_Container)
     elif CC == 'N' :
        return 1
     else :
        print("잘못입력하셨습니다. 다시입력하세요")
        CC=input("2006_1분기부터 2019_1분기까지의 Container를 확인하시겠습니까 (Y/N) ?").upper()
        Container_All(CC)

# 년/분기별 개별 Container 출력 함수
def Container_Y_Q(CC):
    New_Data_Container=Container_Pre()  
    if CC == 'Y' :
        Y_Q = input("연도_분기를 입력하시오(ex : '2012_3')")
        print(New_Data_Container.loc[Y_Q])
        return 1
    elif CC == 'N' :
        return 1
    else :
        print("잘못입력하셨습니다. 다시입력하세요")
        Container_Confirm=input("특정 년도/분기의 Container를 확인하시겠습니까 (Y/N) ?").upper()
        Container_Y_Q(Container_Confirm)